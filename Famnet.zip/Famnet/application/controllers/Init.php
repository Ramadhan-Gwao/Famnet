<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Init extends CI_Controller {
    public function index(){
        $this->form_validation->set_rules('email','Email','trim|required|min_length[5]');
        $this->form_validation->set_rules('password','Password','trim|required|min_length[6]');
        if ($this->form_validation->run() == FALSE) {
            $data['page'] = 'login';
		    $this->load->view('layouts/header');
		    $this->load->view('index',$data);
            $this->load->view('layouts/footer');
        }else{
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            $data = array(
                'email' => $email,
                'password' => $password,
            );
            $user_id = $this->user_model->user_login($email,$password);
            if ($user_id) {
                $this->user_model->activate_user($user_id);
                $user_data = array('user_id'=>$user_id,'email'=>$email,'logged_in'=>true);  
                $this->session->set_userdata($user_data);
                $this->session->set_flashdata('register_success','You are successfully registered');
                redirect('home');
            }else {
                $this->session->set_flashdata('not_loggedin','Wrong email/password');
                $data['page'] = 'login';
		        $this->load->view('layouts/header');
		        $this->load->view('index',$data);
                $this->load->view('layouts/footer');
                
            }
        }
    }
    public function register(){
        $this->form_validation->set_rules('email','Email','trim|required|min_length[5]');
        $this->form_validation->set_rules('password','Password','trim|required|min_length[6]');
        $this->form_validation->set_rules('re_type_password','Confirm Password','trim|required|matches[password]');
        if ($this->form_validation->run() == FALSE) {
            $data['errors'] =  array('errors'=>validation_errors());
            $data['page'] = 'register';
		    $this->load->view('layouts/header');
		    $this->load->view('index',$data);
            $this->load->view('layouts/footer');
        }else{
            $email = $this->input->post('email');
            $password = password_hash($this->input->post('password'),PASSWORD_DEFAULT);
            $users_data = array(
                'first_name' => $this->input->post('first_name'),
                'last_name' => $this->input->post('last_name'), 
                
                'email' => $email,
                'password' => $password,
                'birth_date' => $this->input->post('birth_date'));
            $register = $this->user_model->register_new_user($users_data);
            if ($register) {
                $user_id = $this->user_model->user_login($email,$password);
            }
            if ($register && $user_id) {
                $user_data = array('user_id'=>$user_id,'email'=>$email,'logged_in'=>true); 
                $this->user_model->activate_user($user_id); 
                $this->session->set_userdata($user_data);
                $this->session->set_flashdata('register_success','You are successfully registered');
                redirect('home');
            }
        }

    }
    public function logout(){
        $this->session->sess_destroy();
        $this->user_model->deactivate_user($this->session->userdata('user_id'));
        redirect('init');
    }
    public function forgot_password(){
        
    }
}