<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chats extends CI_Controller {
    public function __construct(){
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            $this->session->set_flashdata('not_loggedin','You are not logged in. Please log in.');
            redirect('init');
        }
    }
    public function index(){
        $data['chats'] = $this->chat_model->get_all_user_chats($this->session->userdata('user_id'));
        foreach ($data['chats'] as $chat) {
            if ($chat->creator_id == $this->session->userdata('user_id')) {
                $chat->created_at = array($this->user_model->get_user_credentials($chat->participant_id));
            }elseif ($chat->participant_id == $this->session->userdata('user_id')) {
                $chat->created_at = array($this->user_model->get_user_credentials($chat->creator_id));
            }
        }
        $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
        $data['nav'] = 'chats';
        $data['main_view'] = 'chats/all_chats';
        $this->load->view('layouts/header');
        $this->load->view('main',$data);
        $this->load->view('layouts/footer');
    }
    public function create_conversation(){
        $this->form_validation->set_rules('message','Message','required');
        $this->form_validation->set_rules('email','Recipient','required');
        if($this->form_validation->run()==false){
            $data['errors'] =  array('errors'=>validation_errors());
            $data['users'] = $this->user_model->get_users_credentials();
            $data['main_view'] = 'chats/create_chat';
            $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
            $data['nav'] = 'chats';
            $this->load->view('layouts/header');
            $this->load->view('main',$data);
            $this->load->view('layouts/footer');
        }else{
            $conv = array(
            'creator_id'=>$this->session->userdata('user_id'),
            'participant_id'=>$this->user_model->get_user_by_email($this->input->post('email')),
            'updated_at' => date('Y-m-d h:m:i')
            );
            if($this->chat_model->create_chat($conv)){
                $message = array(
                    'conv_id'=>1,
                    'sender_id' => $this->session->userdata('user_id'),
                    'participant_id'=> $this->user_model->get_user_by_email($this->input->post('email')),
                    'message'=>$this->input->post('message'),
                    'viewed' => 0
                );
                if($this->chat_model->compose_message($message)){
                    redirect('chats/index');
                }else{
                    echo 'Error sending message.';
                }
            }

        }
    }
    public function conversation($email,$conv_id){
        $this->form_validation->set_rules('message','Message','trim|required');
        if ($this->form_validation->run() == FALSE) {
            $user_email = urldecode($email);
            $data['user_messages'] = $this->chat_model->get_all_users_chat_messages($this->session->userdata('user_id'),$this->user_model->get_user_by_email($user_email),$conv_id);
            $data['errors'] = array('error' => validation_errors());
            $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
            $data['nav'] = 'chats';
            $data['sender1'] = $this->session->userdata('user_id');
            $data['sender2'] = $this->user_model->get_user_by_email($user_email);
            $data['email'] = $this->user_model->get_user_by_email($user_email);
            $data['user'] = $this->user_model->get_user_credentials($this->user_model->get_user_by_email($user_email));
            $data['main_view'] = 'chats/view_chat';
            $data['conv_id'] = $conv_id;
            $this->load->view('layouts/header');
            $this->load->view('main',$data);
            $this->load->view('layouts/footer');
            $this->load->view('javascript/chat',$data);
        }
    }
    public function send_message($conv_id,$email){
        $message = array(
            'conv_id'=>$conv_id,
            'sender_id' => $this->session->userdata('user_id'),
            'participant_id'=> $this->user_model->get_user_by_email(urldecode($email)),
            'message'=>$this->input->post('message'),
            'viewed' => 0
        );
        if($this->chat_model->compose_message($message)){
            echo $this->input->post('message');
        }else{
            echo 'Error sending message.';
        }

    }
    public function delete($message_id){
        if(!$this->chat_model->delete_message($message_id)){
            $this->session->set_flashdata('failed_delete','Failed to delete message!');
        }else{
            echo 'success';
        }
        
    }
}
/*
http://mfikri.com/en/blog/crud-codeigniter-ajax
https://www.itsolutionstuff.com/post/jquery-ajax-request-example-in-codeigniterexample.html
https://www.codexworld.com/codeigniter-upload-multiple-files-images/*/