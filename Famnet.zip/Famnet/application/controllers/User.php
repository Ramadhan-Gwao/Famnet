<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
    public function __construct(){
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            $this->session->set_flashdata('not_loggedin','You are not logged in. Please log in.');
            redirect('init');        }
    }
    public function profile(){
        $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
        $data['posts'] = $this->action_model->get_user_posts($this->session->userdata('user_id'));
        foreach ($data['posts'] as $post) {
            $data['likes'] = $this->action_model->get_post_likes($post->post_id);
        }
        for($i = 0; $i < count($data['posts']);$i++) {
            $data['comment'][$i] = $this->action_model->get_post_comments($data['posts'][$i]->post_id);
        }
        for($i = 0; $i < count($data['posts']);$i++) {
            for ($j=0; $j < count($data['comment'][$i]); $j++) { 
                $data['comment'][$i][$j]->user_id = $this->user_model->get_user_credentials($data['comment'][$i][$j]->user_id);
            }
        }
        $data['post_pics'] = $this->action_model->get_user_post_pictures($this->session->userdata('user_id'));
        $data['nav'] = 'profile';
        $data['user_info'] = $this->user_model->get_user_data($this->session->userdata('user_id'));
        $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
        $data['main_view'] = 'user/user_profile';
        $this->load->view('layouts/header');
        $this->load->view('main',$data);
        $this->load->view('layouts/footer');
        $this->load->view('javascript/home');
    }
    public function edit_profile(){
        $result = $this->user_model->check_user_contacts($this->session->userdata('user_id'));
        $this->form_validation->set_rules('email','Email','trim|required');
        if ($this->form_validation->run() == false) {
            if(!$result){
                $data['user_contacts'] = $this->user_model->get_user_contacts($this->session->userdata('user_id'));
                $data['user_data'] = $this->user_model->get_user_data($this->session->userdata('user_id'));
            }
            $data['user_data'] = $this->user_model->get_user_data($this->session->userdata('user_id'));
            $data['nav'] = 'profile';
            $data['user_info'] = $this->user_model->get_user_data($this->session->userdata('user_id'));
            $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
            $data['main_view'] = 'user/edit_profile';
            $this->load->view('layouts/header');
            $this->load->view('main',$data);
            $this->load->view('layouts/footer');
            $this->load->view('javascript/home');
        }   
    }
    public function do_upload(){
        $config['upload_path']          = './profile_upload/';
        $config['allowed_types']        = 'gif|jpg|png|jepg';
        $config['max_size']             = 100000000;
        $config['file_name'] = count($this->upload_model->check())+1;
        /*$config['max_width']            = 1024;
        $config['max_height']           = 768;*/
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('userfile')){
            $data['errors'] = array('error' => $this->upload->display_errors());
            $this->session->set_flashdata('upload_fail','Oops! Something went wrong!');
            $data['nav'] = 'profile';
            $data['user_info'] = $this->user_model->get_user_data($this->session->userdata('user_id'));
            $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
            $data['main_view'] = 'user/user_profile';
            $this->load->view('layouts/header');
            $this->load->view('main',$data);
            $this->load->view('layouts/footer');
        }else{
            $data['database'] = ['user_id'=> $this->session->userdata('user_id'),'pic_name'=>$this->upload->data('file_name'),'active'=>1];
            $this->upload_model->unmark_profile_pictures($this->session->userdata('user_id'));
            $this->upload_model->upload_profile_picture($data['database']);
            $this->session->set_flashdata('upload success!','Successfully uploaded!');
            redirect('user/profile');
        }
    }
    public function post(){
        if (!isset($_POST['userfile'])) {
            $config['upload_path']          = './post_upload/';
            $config['allowed_types']        = 'gif|jpg|png|jepg|jpeg';
            $config['max_size']             = 100000000;
            $file = $this->upload_model->check_post_picture();
            $config['file_name'] = ($file->post_pic_id) + 2;
            /*$config['max_width']            = 1024;
            $config['max_height']           = 768;*/
            $this->load->library('upload', $config);
            if ( ! $this->upload->do_upload('userfile')){
                $data['errors'] = array('error' => $this->upload->display_errors());
                $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
                $data['nav'] = 'home';
                $data['main_view'] = 'home';
                $this->load->view('layouts/header');
                $this->load->view('main',$data);
                $this->load->view('layouts/footer');
            }else{
                $post = array('user_id' => $this->session->userdata('user_id'),'content' => $this->input->post('content'));
                $this->action_model->create_post($post); 
                $post = $this->action_model->get_last_user_post($this->session->userdata('user_id'));
                $post_data = array($this->upload->data());
                $data['database'] = ['user_id'=> $this->session->userdata('user_id'),'pic_name'=>$this->upload->data('file_name'),'post_id'=>$post->post_id];
                $this->upload_model->upload_post_picture($data['database']);
                redirect('home/index');
            }
        }else {
            $data['errors'] = array('error'=>'Upload Fail');
            $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
            $data['nav'] = 'home';
            $data['main_view'] = 'home';
            $this->load->view('layouts/header');
            $this->load->view('main',$data);
            $this->load->view('layouts/footer'); 
        }
        
    }
    public function edit_post($post_id){
        $this->form_validation->set_rules('content','Content','required|min_length[1]');
        if ($this->form_validation->run()==FALSE) {
            $data['post'] = $this->action_model->get_post($post_id);
            $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
            $data['nav'] = 'home';
            $data['post_id'] = $post_id;
            $data['main_view'] = 'post/edit_post';
            $this->load->view('layouts/header');
            $this->load->view('main',$data);
            $this->load->view('layouts/footer'); 
            $this->load->view('javascript/home');
        }else{
            $post = array('content'=>$this->input->post('content'));
            if (!$this->action_model->update_post($post_id,$post)) {
                $data['post'] = $this->action_model->get_post($post_id);
                $data['post_id'] = $post_id;
                $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
                $data['nav'] = 'home';
                $data['main_view'] = 'post/edit_post';
                $this->load->view('layouts/header');
                $this->load->view('main',$data);
                $this->load->view('layouts/footer');
                $this->load->view('javascript/home');

            }else{
                $this->session->set_flashdata('post_updated','Post successfully edited');
                redirect('home/index');
            }
            
        }
    }
    public function like($post_id){
        if ($this->action_model->check_like($post_id,$this->session->userdata('user_id'))) {
            
            if($this->action_model->check_active_like($post_id,$this->session->userdata('user_id'))){
                
                if ($this->action_model->re_like_post($post_id,$this->session->userdata('user_id'))) {
                    echo 'Reliked';
                }

            }elseif(!$this->action_model->check_active_like($post_id,$this->session->userdata('user_id'))){
                
                if ($this->action_model->unlike_post($post_id,$this->session->userdata('user_id'))) {
                    echo 'Unliked';
                }

            }
            
        }else{
            
            if($this->action_model->like_post($post_id,$this->session->userdata('user_id'))){
                echo 'Liked';
            }else{
                echo 'Failed like';
            }
        }
    }
    public function comment($post_id){
        
        $comment = array('post_id'=>$post_id,'user_id'=>$this->session->userdata('user_id'),'comment'=>$this->input->post('comment'));
        
        if($this->action_model->comment($comment)){
            $query = $this->action_model->get_inputs($post_id,$this->session->userdata('user_id'));
            echo $query[0]->comment;
        }else{
            echo 'Failed to comment';
        }
    }
    public function get($post_id){
        $query = $this->action_model->get_inputs($post_id,$this->session->userdata('user_id'));
        foreach ($query as $q) {
            echo $q->comment;
        }
        echo $query[0]->comment;
    }
}
?>