<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Project extends CI_Controller {
    public function __construct(){
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            $this->session->set_flashdata('not_loggedin','You are not logged in. Please log in.');
            redirect('init');
        }
    }
    public function index(){
        $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
        $data['nav'] = 'project';
        $data['main_view'] = 'projects/view_all';
        $data['projects'] = $this->project_model->get_projects();
        $this->load->view('layouts/header');
        $this->load->view('main',$data);
        $this->load->view('layouts/footer');
    }
    public function new(){
        $this->form_validation->set_rules('project_name','Project_name','required');
        if ($this->form_validation->run() == FALSE) {
            $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
            $data['nav'] = 'project';
            $data['users'] = $this->user_model->get_users_credentials();
            $data['main_view'] = 'projects/create_project';
            $this->load->view('layouts/header');
            $this->load->view('main',$data);
            $this->load->view('layouts/footer');
        }else {
            $project = array(
                'project_name' => $this->input->post('project_name'),
                'project_desc' => $this->input->post('project_desc'),
                'status' => $this->input->post('status'),
                'project_leader' => $this->input->post('project_leader')
            );
            if($this->project_model->create_project($project)){
                $project_id = $this->project_model->get_last_project_id();
                $project_budget = array(
                    'project_id' => $project_id,
                    'estimated_budget' => $this->input->post('estimated_budget'),
                    'total_amount_spent' => $this->input->post('amount_spent'),
                    'project_duration' => $this->input->post('duration'),
                    'sponsored_by' => $this->input->post('sponsor')
                );
                foreach($_FILES['file[]'] as $file){
                    $config['upload_path']          = './project_upload/';
                    $config['allowed_types']        = 'gif|jpg|png';
                    $config['max_size']             = 100000;
                    $size = $this->upload_model->get_last_project_picture();
                    if (!isset($size)) {
                        $size == 0;
                    }
                    $config['file_name'] = $size + 1;
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload($file)){
                    $data['database'] = ['project_id'=> $this->project_model->get_last_project_id(),'pic_name'=>$config['file_name']];
                    $this->upload_model->upload_project_picture($data['database']);
                    }
                }


                if($this->project_model->create_budget($project_budget)){
                    redirect('project');
                }                
            }else {
                $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
                $data['nav'] = 'project';
                $data['main_view'] = 'projects/create_project';
                $this->load->view('layouts/header');
                $this->load->view('main',$data);
                $this->load->view('layouts/footer');
            }
            
        }
    }
    public function edit($project_id){
        $this->form_validation->set_rules('project_name','Project_name','required');
        if ($this->form_validation->run() == FALSE) {
            $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
            $data['nav'] = 'project';
            $data['projects'] = $this->project_model->get_project($project_id);
            $data['budget'] = $this->project_model->get_budget($project_id);
            $data['main_view'] = 'projects/edit_project';
            $this->load->view('layouts/header');
            $this->load->view('main',$data);
            $this->load->view('layouts/footer');
        }else {
            $project = array(
                'project_name' => $this->input->post('project_name'),
                'project_desc' => $this->input->post('project_desc'),
                'status' => $this->input->post('status'),
                'project_leader' => $this->input->post('project_leader')
            );
            if($this->project_model->edit_project($project_id,$project)){
                $project_id = $this->project_model->get_last_project_id();
                $project_budget = array(
                    'project_id' => $project_id,
                    'estimated_budget' => $this->input->post('estimated_budget'),
                    'total_amount_spent' => $this->input->post('amount_spent'),
                    'project_duration' => $this->input->post('duration'),
                    'sponsored_by' => $this->input->post('sponsor')
                );

                if($this->project_model->edit_budget($project_id,$project_budget)){
                    redirect('project');
                }                
            }else {
                $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
                $data['nav'] = 'project';
                $data['main_view'] = 'projects/edit_project';
                $this->load->view('layouts/header');
                $this->load->view('main',$data);
                $this->load->view('layouts/footer');
            }
        }
    }
    public function delete($project_id){
        $result = $this->project_model->delete_project($project_id);
        $result1 = $this->project_model->delete_budget($project_id);
        if ($result && $result1) {
            redirect('project');
        }else {
            redirect('project');
        }

    }
    public function display($project_id){
        $data['nav'] = 'project';
        $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
        $data['main_view'] = 'projects/display';
        $data['project'] = $this->project_model->get_project($project_id);
        $data['budget'] = $this->project_model->get_budget($project_id);
        $this->load->view('layouts/header');
        $this->load->view('main',$data);
        $this->load->view('layouts/footer');
    }
}
 function do_upload()
        {
                $config['upload_path']          = './uploads/';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 100000;
                $config['file_name'] = count($this->upload_model->check())+1;
                /*$config['max_width']            = 1024;
                $config['max_height']           = 768;*/

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('file'))
                {
                    $error = array('error' => $this->upload->display_errors());
                    $data['main_view'] = 'upload_form';
                    $data['nav'] = 'upload';
                    $data['error'] = $error;
                    $this->load->view('layouts/header');
                    $this->load->view('home',$data);
                    $this->load->view('layouts/footer');
                }
                else
                {   
                    $data['database'] = ['user_id'=> $this->session->userdata('user_id'),'pic_name'=>$config['file_name']];
                    $this->upload_model->upload($data['database']);
                    $data = array('upload_data' => $this->upload->data());

                    $this->load->view('upload_success', $data);
                }
        }