<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    public function __construct(){
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            $this->session->set_flashdata('not_loggedin','You are not logged in. Please log in.');
            redirect('init');
        }
    }
    public function index(){
        $data['profile_pic'] = $this->upload_model->get_user_active_profile_picture($this->session->userdata('user_id'));
        $data['posts'] = $this->action_model->get_posts();
        foreach ($data['posts'] as $post) {
            $data['likes'] = $this->action_model->get_post_likes($post->post_id);
        }
        for($i = 0; $i < count($data['posts']);$i++) {
            $data['comment'][$i] = $this->action_model->get_post_comments($data['posts'][$i]->post_id);
        }
        for($i = 0; $i < count($data['posts']);$i++) {
            for ($j=0; $j < count($data['comment'][$i]); $j++) { 
                $data['comment'][$i][$j]->user_id = $this->user_model->get_user_credentials($data['comment'][$i][$j]->user_id);
            }
             
        }
        $data['nav'] = 'home';
        $data['main_view'] = 'home';
        $this->load->view('layouts/header');
        $this->load->view('main',$data);
        $this->load->view('layouts/footer');
        $this->load->view('javascript/home');
    }
    function practice(){
        $this->load->view('layouts/header');
        $this->load->view('practice');
        echo '</body></html>';
    }
}