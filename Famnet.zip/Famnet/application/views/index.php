<div class="hold-transition login-page">
<?php if($page == "login"): ?>
<?php $this->load->view('forms/login_form');?>
<?php elseif($page == 'register'): ?>
<?php $this->load->view('forms/register_form');?>
<?php endif; ?>
</div>