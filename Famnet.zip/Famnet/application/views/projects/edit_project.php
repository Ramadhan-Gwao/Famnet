<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Project Add</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active">Project Add</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <form action="<?php echo base_url()?>project/edit/<?php echo $projects->project_id?>" method="post">
      <div class="row">
        <div class="col-md-6">
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">General</h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                  <i class="fas fa-minus"></i></button>
              </div>
            </div>
            <div class="card-body">
              <div class="form-group">
                <label for="inputName">Project Name</label>
                <input type="text" name="project_name" id="inputName" value="<?php echo $projects->project_name; ?>" class="form-control">
              </div>
              <div class="form-group">
                <label for="inputDescription">Project Description</label>
                <textarea id="inputDescription" name="project_desc" class="form-control" rows="4"><?php echo $projects->project_desc;?></textarea>
              </div>
              <div class="form-group">
                <label for="inputStatus">Status</label>
                <select name="status" class="form-control custom-select">
                  <option  selected="" disabled="">Select one</option>
                  <option value='on hold'>On Hold</option>
                  <option value='canceled'>Canceled</option>
                  <option value='success'>Success</option>
                </select>
              </div>
              <div class="form-group">
                <label for="inputProjectLeader">Project Leader</label>
                <input type="text" value="<?php echo $projects->project_leader; ?>" name="project_leader" id="inputProjectLeader" class="form-control">
              </div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <div class="col-md-6">
          <div class="card card-secondary">
            <div class="card-header">
              <h3 class="card-title">Budget</h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                  <i class="fas fa-minus"></i></button>
              </div>
            </div>
            <div class="card-body">
              <div class="form-group">

                <label for="inputEstimatedBudget">Estimated budget</label>
                <input type="number" value="<?php echo $budget->estimated_budget; ?>" name="estimated_budget" id="inputEstimatedBudget" class="form-control">
              </div>
              <div class="form-group">
                <label for="inputSpentBudget">Total amount spent</label>
                <input type="number" value="<?php echo $budget->total_amount_spent; ?>" name="amount_spent" id="inputSpentBudget" class="form-control">
              </div>
              <div class="form-group">
                <label for="inputEstimatedDuration">Estimated project duration</label>
                <input type="number" value="<?php echo $budget->project_duration ?>" name="duration" id="inputEstimatedDuration" class="form-control">
              </div>
              <div class="form-group">
                <label for="inputEstimatedDuration">Sponsors</label>
                <input type="number" value="<?php echo $budget->sponsored_by ?>" name="sponsor" id="inputEstimatedDuration" class="form-control">
              </div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      </div>
      <div class="row">
        <div class="col-12">
          <a href="<?php echo base_url();?>project" class="btn btn-secondary">Cancel</a>
          <input type="submit" value="Edit Porject" class="btn btn-success float-right">
        </div>
      </div>
      </form>
    </section>