<br/>
<div class="content-wrapper">
<div class="container">
		<div class="row">
			
					
			<?php if(!$post->post_pic == ''): ?>
			<div class="col-md-7">
            <!-- Box Comment -->
            <div class="card card-widget">
              <div class="card-header">
                <div class="user-block">
                  <img class="img-circle" src="<?php echo base_url();?>profile_upload/<?php echo $post->prof_pic ?>" alt="User Image">
                  <span class="username"><a href="#"><?php echo ucfirst($post->first_name).' '.ucfirst($post->last_name); ?></a></span>
                  <span class="description">Date created - <?php echo $post->date_created ?></span>
                </div>
                <!-- /.user-block -->
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                  </button>
                </div>
                <!-- /.card-tools -->
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <img class="img-fluid pad" src="<?php echo base_url(); ?>post_upload/<?php echo $post->post_pic;?>" alt="Photo">
                &nbsp;
                <p>Edit Your Post:</p>
                <form action="<?php base_url();?>user/edit_post/<?php echo $post_id; ?>" method="post">
                    <textarea name="content" ><?php echo $post->content;?></textarea>
                    <input type="submit" class="btn btn-primary" value="Update post"/>
                </form>
                &nbsp; <br>
                <button type="button" class="btn btn-default btn-sm"><i class="fas fa-share"></i> Share</button>
                <button type="button" class="btn btn-default btn-sm"><i class="far fa-thumbs-up"></i> Like</button>
                <span class="float-right text-muted">127 likes - 3 comments</span>
              </div>
              <!-- /.card-body -->
              <div class="card-footer card-comments">                
              </div>
              <!-- /.card-footer -->
              <div class="card-footer">
                <form action="#" method="post">
                  <img class="img-fluid img-circle img-sm" src="<?php echo base_url(); ?>profile_upload/<?php echo $profile_pic->pic_name; ?>" alt="Alt Text">
                  <!-- .img-push is used to add margin to elements next to floating images -->
                  <div class="img-push">
                    <input type="text" class="form-control form-control-sm" placeholder="Press enter to post comment">
                  </div>
                </form>
              </div>
              <!-- /.card-footer -->
            </div>
            <!-- /.card -->
          </div>


        <?php elseif($post->post_pic==''): ?>
		  <div class="col-md-7">
            <!-- Box Comment -->
            <div class="card card-widget">
              <div class="card-header">
                <div class="user-block">
                  <img class="img-circle" src="<?php echo base_url();?>profile_upload/<?php echo $post->prof_pic ?>" alt="User Image">
                  <span class="username"><a href="#"><?php echo ucfirst($post->first_name).' '.ucfirst($post->last_name); ?></a></span>
                  <span class="description">Date created - <?php echo $post->date_created ?></span>
                </div>
                <!-- /.user-block -->
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                  </button>
                </div>
                <!-- /.card-tools -->
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <!-- post text -->
                
                <form action="<?php base_url();?>user/edit_post/<?php echo $post_id; ?>" method="post">
                    <textarea name="content" ><?php echo $post->content;?></textarea>
                    <br><input type="submit" class="btn btn-primary" value="Update post"/>
                </form>
                
                <!-- Social sharing buttons -->
                <br>
                <button type="button" class="btn btn-default btn-sm"><i class="fas fa-share"></i> Share</button>
                <button type="button" class="btn btn-default btn-sm"><i class="far fa-thumbs-up"></i> Like</button>
                <span class="float-right text-muted">45 likes - 2 comments</span>
              </div>
              <!-- /.card-body -->
			  
              <!-- /.card-footer -->
              <div class="card-footer">
                <form action="#" method="post">
                  <img class="img-fluid img-circle img-sm" src="<?php echo base_url(); ?>profile_upload/<?php echo $profile_pic->pic_name; ?>" alt="Alt Text">
                  <!-- .img-push is used to add margin to elements next to floating images -->
                  <div class="img-push">
                    <input type="text" class="form-control form-control-sm" placeholder="Press enter to post comment">
                  </div>
                </form>
              </div>
              <!-- /.card-footer -->
            </div>
            <!-- /.card -->
          </div>
		<?php endif; ?>
		
							</div>

			<br>
			<br>
		</div>
	</div>
    </div>