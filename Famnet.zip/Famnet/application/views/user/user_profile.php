
<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Profile</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">User Profile</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-3">

            <!-- Profile Image -->
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                <?php if(isset($errors)): ?>
                <?php foreach($errors as $error): ?>
                <?php echo '<div>'.$error.'</div>'?>
                <?php endforeach;?>
                <?php endif;?>
                  <img class="profile-user-img img-fluid img-circle"
                       src="<?php echo base_url(); ?>profile_upload/<?php echo $profile_pic->pic_name;?>"
                       alt="User profile picture">
                </div>
                <div class="text-center"><i class="fas fa-camera-retro"></i></div>
                <h3 class="profile-username text-center"><?php echo $user_info->first_name; ?>  <?php echo $user_info->last_name ?></h3>

                <p class="text-center"><a href="<?php echo base_url(); ?>user/edit_profile" class="btn btn-app">
                  <i class="fas fa-edit"></i> Edit Your Profile
                </a></p>

                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <b>Followers</b> <a class="float-right">1,322</a>
                  </li>
                  <li class="list-group-item">
                    <b>Following</b> <a class="float-right">543</a>
                  </li>
                  <li class="list-group-item">
                    <b>Friends</b> <a class="float-right">13,287</a>
                  </li>
                </ul>
                <form action="<?php echo base_url(); ?>user/do_upload" enctype="multipart/form-data" method="post">
                <div class="custom-file">
  											<input type="file" name="userfile" class="custom-file-input" id="customFile">
  											<label class="custom-file-label" for="customFile">Choose a Picture</label>
								</div>
                <input type="submit" class="btn btn-primary btn-block" value="Upload Profile Picture"></input>
                </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

            <!-- About Me Box -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">About Me</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <strong><i class="fas fa-book mr-1"></i> Education</strong>

                <p class="text-muted">
                  B.S. in Computer Science from the University of Tennessee at Knoxville
                </p>

                <hr>

                <strong><i class="fas fa-map-marker-alt mr-1"></i> Location</strong>

                <p class="text-muted">Malibu, California</p>

                <hr>

                <strong><i class="fas fa-pencil-alt mr-1"></i> Skills</strong>

                <p class="text-muted">
                  <span class="tag tag-danger">UI Design</span>
                  <span class="tag tag-success">Coding</span>
                  <span class="tag tag-info">Javascript</span>
                  <span class="tag tag-warning">PHP</span>
                  <span class="tag tag-primary">Node.js</span>
                </p>

                <hr>

                <strong><i class="far fa-file-alt mr-1"></i> Notes</strong>

                <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam fermentum enim neque.</p>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-md-9">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                  <li class="nav-item"><a class="nav-link active" href="#activity" data-toggle="tab">Posts</a></li>
                  <li class="nav-item"><a class="nav-link" href="#timeline" data-toggle="tab">Photos</a></li>
                  <li class="nav-item"><a class="nav-link" href="#settings" data-toggle="tab">Projects</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  <div class="active tab-pane" id="activity">
                   

                    <!-- Post -->
                    
                      
                      <!-- /.user-block -->
                    
                    <!-- /.post -->

                    <!-- Post -->
                    <div class="post">
                    <?php foreach($posts as $post): ?>
			<?php if(!$post->post_pic == ''): ?>
        <div class="post clearfix">
			<div class="col-md">
            <!-- Box Comment -->
            <div class="card card-widget">
              <div class="card-header">
                <div class="user-block">
                  <img class="img-circle" src="<?php echo base_url();?>profile_upload/<?php echo $post->prof_pic ?>" alt="User Image">
                  <span class="username"><a href="#"><?php echo ucfirst($post->first_name).' '.ucfirst($post->last_name); ?></a></span>
                  <span class="description">Date created - <?php echo $post->date_created ?></span>
                </div>
                <!-- /.user-block -->
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                  </button>

                  <div class="btn-group">
                  <button type="button" class="btn btn-white dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Action
                  </button>
                  <div class="dropdown-menu">
                    <a class="dropdown-item" href="#">Report</a>
                    <a href="<?php echo base_url();?>user/edit_post/<?php echo $post->post_id; ?>" class="dropdown-item">Edit Post</i>
                    <a class="dropdown-item" href="#">Something else here</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="#">Separated link</a>
                  </div>
                  </div>
                  </a>
                </div>
                <!-- /.card-tools -->
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <img class="img-fluid pad" src="<?php echo base_url(); ?>post_upload/<?php echo $post->post_pic;?>" alt="Photo">

                <p><?php echo $post->content;?></p>
                <button type="button" class="btn btn-default btn-sm"><i class="fas fa-share"></i> Share</button>
                <button type="button" id="<?php echo $post->post_id; ?>" class="likes" class="btn btn-default btn-sm-danger"><i class="far fa-thumbs-up"></i> Like</button>
                <span class="float-right text-muted"><?php //foreach($likes as $like){if($post->post_id == $like->post_id){++$count;}} echo $count;$count =0;  ?> likes - 3 comments</span>
              </div>
              <!-- /.card-body -->
              <div class="card-footer card-comments"> 
				<?php for ($i=0; $i < count($comment) ; $i++):?>
				<?php for ($j=0; $j < count($comment[$i]); $j++):?>
				<?php if($comment[$i][$j]->post_id == $post->post_id): ?>
					<div class="card-comment">
                  	<!-- User image -->
                  		<img class="img-circle img-sm" src="<?php echo base_url(); ?>profile_upload/<?php echo $comment[$i][$j]->user_id->pic_name; ?>" alt="User Image">

                  		<div class="comment-text">
                    		<span class="username">
							<?php echo ucfirst($comment[$i][$j]->user_id->first_name)." ".ucfirst($comment[$i][$j]->user_id->last_name);?>
                    	  	<span class="text-muted float-right"><?php echo $this->custom->get_time($comment[$i][$j]->date_created); ?></span>
                    		</span><!-- /.username -->
                    		<?php echo $comment[$i][$j]->comment ?>
                  		</div>
                  		<!-- /.comment-text -->
                	</div>
                	<!-- /.card-comment -->
				<?php endif;?>
				<?php endfor;?>
				<?php endfor;?>
              </div>
              <!-- /.card-footer -->
              <div class="card-footer">
                <form action="#" method="post">
                  <img class="img-fluid img-circle img-sm" src="<?php echo base_url(); ?>profile_upload/<?php echo $profile_pic->pic_name; ?>" alt="Alt Text">
                  <!-- .img-push is used to add margin to elements next to floating images -->
                  <div class="img-push">
                    <input type="text" name="comment" id="<?php echo $post->post_id; ?>" class="btn btn-outline-light" class="form-control form-control-sm" placeholder="Press enter to post comment">
					<input type="button" class="btn btn-primary comment" value="Comment">
				  </div>
                </form>
              </div>
              <!-- /.card-footer -->
            </div>
            <!-- /.card -->
          </div>
          </div>

        <?php elseif($post->post_pic==''): ?>
          <div class="post clearfix">
		  <div class="col-md">
            <!-- Box Comment -->
            <div class="card card-widget">
              <div class="card-header">
                <div class="user-block">
                  <img class="img-circle" src="<?php echo base_url();?>profile_upload/<?php echo $post->prof_pic ?>" alt="User Image">
                  <span class="username"><a href="#"><?php echo ucfirst($post->first_name).' '.ucfirst($post->last_name); ?></a></span>
                  <span class="description">Date created - <?php echo $post->date_created ?></span>
                </div>
                <!-- /.user-block -->
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                  </button>
                  <div class="btn-group">
                  <button type="button" class="btn btn-white dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                   Action
                  </button>
                  <div class="dropdown-menu">
                  <a href="<?php echo base_url();?>user/edit_post/<?php echo $post->post_id; ?>" class="dropdown-item">Edit Post</i>
                  <a class="dropdown-item" href="#">Report</a>
                  <a class="dropdown-item" href="#">Something else here</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="#">Separated link</a>
                  </div>
                  </div>
                  </a>
                </div>
                <!-- /.card-tools -->
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <!-- post text -->
                <p><?php echo $post->content;?></p>

                <!-- Social sharing buttons -->
                <button type="button" class="btn btn-default btn-sm"><i class="fas fa-share"></i> Share</button>
                <button type="button" id="<?php echo $post->post_id; ?>"  class="likes" class="btn btn-default btn-sm"><i class="far fa-thumbs-up"></i> Like</button>
                <span class="float-right text-muted"><?php //foreach($likes as $like){if($post->post_id == $like->post_id){++$count;}} echo $count;$count =0;  ?> likes - 2 comments</span>
              </div>
              <!-- /.card-body -->
			  <div class="card-footer card-comments">
				<div class="nav"></div>
			  </div>
              <!-- /.card-footer -->
              <div class="card-footer">
                <form action="#" method="post">
                  <img class="img-fluid img-circle img-sm" src="<?php echo base_url(); ?>profile_upload/<?php echo $profile_pic->pic_name; ?>" alt="Alt Text">
                  <!-- .img-push is used to add margin to elements next to floating images -->
                  <div class="img-push">
                    <input type="text" id="<?php echo $post->post_id; ?>" class="btn btn-outline-light" class="form-control form-control-sm" placeholder="Press enter to post comment">
					<input type="button" class="btn btn-primary comment" value="Comment">
				  </div>
                </form>
              </div>
              <!-- /.card-footer -->
            </div>
            <!-- /.card -->
          </div>
          </div>
		<?php endif; ?>
		<?php endforeach; ?>
							</div>
              
                     


                   
                    <!-- /.post -->
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="timeline">
                    <!-- The timeline -->
                    <div class="timeline timeline-inverse">
                      <!-- timeline time label -->
                      <div class="time-label">
                      <div class="post">
                      <div class="row mb-6">
                        <!-- /.col -->
                        <div class="col-sm-9">
                        <div class="row">
                        <?php foreach($post_pics as $pic):?>
                          
                            <div class="col-sm-6">
                              <img class="img-fluid mb-3" src="<?php echo base_url();?>post_upload/<?php echo $pic->pic_name;?>" alt="Photo">
                            </div>
                            <!-- /.col -->
                        <?php endforeach; ?>
                        </div>
                          <!-- /.row -->
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->
                    </div>


                      </div>
                    </div>
                  </div>
                  <!-- /.tab-pane -->

                  <div class="tab-pane" id="settings">
                    <form class="form-horizontal">
                      <div class="form-group row">
                        <label for="inputName" class="col-sm-2 col-form-label">Name</label>
                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="inputName" placeholder="Name">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail" class="col-sm-2 col-form-label">Email</label>
                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="inputEmail" placeholder="Email">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputName2" class="col-sm-2 col-form-label">Name</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" id="inputName2" placeholder="Name">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputExperience" class="col-sm-2 col-form-label">Experience</label>
                        <div class="col-sm-10">
                          <textarea class="form-control" id="inputExperience" placeholder="Experience"></textarea>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputSkills" class="col-sm-2 col-form-label">Skills</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" id="inputSkills" placeholder="Skills">
                        </div>
                      </div>
                      <div class="form-group row">
                        <div class="offset-sm-2 col-sm-10">
                          <div class="checkbox">
                            <label>
                              <input type="checkbox"> I agree to the <a href="#">terms and conditions</a>
                            </label>
                          </div>
                        </div>
                      </div>
                      <div class="form-group row">
                        <div class="offset-sm-2 col-sm-10">
                          <button type="submit" class="btn btn-danger">Submit</button>
                        </div>
                      </div>
                    </form>
                  </div>
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->

<!-- Example single danger button -->



