<div class="card-body login-card-body">
<div class="row">
<div class="col-2"></div>
<div class="col-md-8">
            <!-- DIRECT CHAT DANGER -->
            <div class="card card-primary direct-chat direct-chat-primary shadow-lg">
              <div class="card-header">
              <form action="<?php echo base_url(); ?>chats/create_conversation" method="post">
              <div class="row">
                <div class="col-md-3">
                <h3 class="card-title">Create chat</h3>
                </div>
                
                <div class="col-md-5">
                    <div class="form-group">
                        <!--<label>Minimal</label>-->
                        <select name="email" class="form-control select2" style="width: 100%;">
                            <option selected="selected">Select recipient</option>
                            <?php foreach($users as $user): ?>
                            <option value="<?php echo $user->email;?>"><?php echo $user->first_name." ".$user->last_name;?></option>
                            <?php endforeach;?>
                        </select>
                    </div>
                </div>
                
            </div>
                
                
                
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <!-- Conversations are loaded here -->
                <div class="direct-chat-messages">
                  <!-- Message. Default to the left -->
                  <div class="direct-chat-msg">
                    
                    <?php foreach($errors as $error):?>
                      <div class="direct-chat-infos clearfix">
                      <?php echo $error ?>
                      </div>
                    <?php endforeach;?>
                    
                    <!-- /.direct-chat-text -->
                  </div>
                  <!-- /.direct-chat-msg -->

                  <!-- Message to the right -->
                  <div class="direct-chat-msg right">
                    <div class="direct-chat-infos clearfix">
                      <span class="direct-chat-name float-right">Sarah Bullock</span>
                      <span class="direct-chat-timestamp float-left"></span>
                    </div>
                    <!-- /.direct-chat-infos -->
                    <img class="direct-chat-img" src="../dist/img/user3-128x128.jpg" alt="Message User Image">
                    <!-- /.direct-chat-img -->
                    <div class="direct-chat-text float-right">
                      You better believe it!
                    </div>
                    <!-- /.direct-chat-text -->
                  </div>
                  <!-- /.direct-chat-msg -->
                </div>
                <!--/.direct-chat-messages-->

                <!-- Contacts are loaded here -->
                <div class="direct-chat-contacts">
                  <ul class="contacts-list">
                    <li>
                      <a href="#">
                        <img class="contacts-list-img" src="../dist/img/user1-128x128.jpg" alt="User Avatar">

                        <div class="contacts-list-info">
                          <span class="contacts-list-name">
                            Count Dracula
                            <small class="contacts-list-date float-right">2/28/2015</small>
                          </span>
                          <span class="contacts-list-msg">How have you been? I was looking for ya all the way my friend.</span>
                        </div>
                        <!-- /.contacts-list-info -->
                      </a>
                    </li>
                    <!-- End Contact Item -->
                  </ul>
                  <!-- /.contatcts-list -->
                </div>
                <!-- /.direct-chat-pane -->
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                
                  <div class="input-group">
                    <input type="text" name="message" placeholder="Type Message ..." class="form-control">
                    <span class="input-group-append">
                      <button type="submit" class="btn btn-danger">Send</button>
                    </span>
                  </div>
                </form>
              </div>
              <!-- /.card-footer-->
            </div>
            <!--/.direct-chat -->
          </div>
          </div>
          </div>