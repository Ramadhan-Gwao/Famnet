<div class="card-body login-card-body">
<div class="row">
<div class="col-2"></div>
<div class="col-md-8">
            <!-- DIRECT CHAT PRIMARY -->
            <div class="card card-primary direct-chat direct-chat-primary shadow-lg">
              <div class="card-header">
              <img alt="Avatar" class="direct-chat-img" src="<?php echo base_url().'profile_upload/'.$user->pic_name?>">
                <h3 class="card-title"><?php echo $user->first_name; ?></h3>
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" title="Contacts" data-widget="chat-pane-toggle">
                    <i class="fas fa-comments"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <!-- Conversations are loaded here -->
                <div class="direct-chat-messages">
                <?php foreach($user_messages as $message):?>
                  <?php if($message->sender_id == $sender1):?>
                    <!-- Message to the right -->
                  <div class="direct-chat-msg right">
                    <!-- /.direct-chat-img -->
                    <div class="direct-chat-text float-right">
                    <?php echo $message->message?>
                    </div>
                    <!-- /.direct-chat-text -->
                  </div>
                  <!-- /.direct-chat-msg -->
                  
                  <!-- /.direct-chat-msg -->
                  <?php elseif($message->sender_id == $sender2):?>
                    <!-- Message. Default to the left -->
                  <div class="direct-chat-msg">
                    <div class="direct-chat-text float-left">
                      <?php echo $message->message?>
                    </div>
                    <!-- /.direct-chat-text -->
                    </div>
                  <?php endif;?>
                <?php endforeach; ?>
                </div>
                <!--/.direct-chat-messages-->
                
                <!-- Contacts are loaded here -->
                <div class="direct-chat-contacts">
                  <ul class="contacts-list">
                    <li>
                      <a href="#">
                        <img class="contacts-list-img" src="../dist/img/user1-128x128.jpg" alt="User Avatar">

                        <div class="contacts-list-info">
                          <span class="contacts-list-name">
                            Count Dracula
                            <small class="contacts-list-date float-right">2/28/2015</small>
                          </span>
                          <span class="contacts-list-msg">How have you been? I was looking for ya all the way ma friend.</span>
                        </div>
                        <!-- /.contacts-list-info -->
                      </a>
                    </li>
                    <!-- End Contact Item -->
                  </ul>
                  <!-- /.contatcts-list -->
                </div>
                <!-- /.direct-chat-pane -->
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                
                  <div class="input-group">
                    <input type="text" name="message" id="message" placeholder="Type Message ..." class="form-control">
                    <span class="input-group-append">
                      <button id="send" class="btn btn-danger">Send</button>
                    </span>
                  </div>

              </div>
              <!-- /.card-footer-->
            </div>
            <!--/.direct-chat -->
          </div>
          </div>
          </div>