&nbsp;
    <div class="col-md-8">
        <div class="card-body p-0">
            <a class="btn btn-primary btn-sm" href="<?php echo base_url(); ?>chats/create_conversation">
                <i class="fas fa-plus">
                </i>
                New Chat
            </a>
          <table class="table table-striped projects">
              <tbody>
                <?php foreach($chats as $chat):?>
                  <tr>
                      <td>
                          <a>
                          <ul class="list-inline">
                              <li class="list-inline-item">
                                  <img alt="Avatar" class="table-avatar" src="<?php echo base_url(); ?>profile_upload/<?php echo $chat->created_at[0]->pic_name; ?>">
                              </li>
                          </ul>
                              <?php echo $chat->created_at[0]->first_name; ?>
                          </a>
                          <br>
                          <small>
                            <?php echo $chat->created_at[0]->updated_at; ?>
                          </small>
                      </td>
                      <td class="project-actions text-right">
                          <a class="btn btn-primary btn-sm" href="<?php echo base_url().'chats/conversation/'.urlencode($chat->created_at[0]->email).'/'.$chat->conversation_id;?>">
                              <i class="fas fa-folder">
                              </i>
                              View
                          </a>
                          <a class="btn btn-danger btn-sm" href="#">
                              <i class="fas fa-trash">
                              </i>
                              Delete
                          </a>
                      </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
          </table>
        </div>
    </div>
    