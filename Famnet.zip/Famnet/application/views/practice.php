<?php
$origin = new DateTime('2021-02-10 02:00:00');
$target = new DateTime(date('Y-M-d h:m:i'));
$interval = $origin->diff($target);
echo $interval->format('%Y years <br> %m months <br> %d days <br> %h hours <br> %i minutes <br> %s seconds<br/><br/><br/>');
$y = $interval->format('%Y');
$m = $interval->format('%m');
$d = $interval->format('%d');
$h = $interval->format('%h');
$i = $interval->format('%i');
$s = $interval->format('%s');


if ($y<=0&&$m<=0&&$d<=0&&$h<=0&&$i<=0) {
    echo $s."seconds ago";
}elseif ($y<=0&&$m<=0&&$d<=0&&$h<=0) {
    echo $i."minutes ago";
}elseif ($y<=0&&$m<=0&&$d<=0) {
    echo $h." h ".$i."minutes ago";
}elseif ($y<=0&&$m<=0) {
    echo $d."days ago";
}elseif ($y<=0) {
    echo $m." month(s) ".$d." day(s) ago";
}elseif ($y >= 1) {
    echo $y." year(s) ".$m." month(s) ".$d." day(s) ago";
}

?>
