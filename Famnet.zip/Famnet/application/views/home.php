<br />
<div class="container">
		<div class="row">

			<div class="col-md-3">
				<ul class="list-group">
					<li class="list-group-item"><span><strong>About Me</strong></span>
					</li>
					<li><div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <img class="profile-user-img img-fluid img-circle" src="<?php echo base_url();?>profile_upload/<?php echo $profile_pic->pic_name;?>">
                </div>
                <div class="text-center"><i class="fas fa-camera-retro"></i></div>
                <h3 class="profile-username text-center">@admin  admin</h3>

                

                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <b>Followers</b> <a class="float-right">1,322</a>
                  </li>
                  <li class="list-group-item">
                    <b>Following</b> <a class="float-right">543</a>
                  </li>
                  <li class="list-group-item">
                    <b>Friends</b> <a class="float-right">13,287</a>
                  </li>
                </ul>

                <a href="#" id="selec" class="btn btn-primary btn-block"><b>Follow</b></a>
              </div>
              <!-- /.card-body -->
            </div></li>
				</ul>
			</div> 

			<div class="col-md-5 "><!-- wall -->
				<div class="panel panel-default">
					<div class="panel-body">
						<form method="post" enctype="multipart/form-data" action="<?php echo base_url(); ?>user/post">
							<div class="form-group">
								<textarea class="form-control" name="content" placeholder="Write on the wall"></textarea>
							</div>
                			<div class="form-group">									
									<div class="custom-file">
  										<input type="file" name="userfile" class="custom-file-input" id="customFile">
  										<label class="btn btn-primary" for="customFile">Choose Picture</label>
										<button class="btn btn-primary" type="submint" style="background-image:url(&quot;none&quot;);background-color:#da052b;color:#fff;padding:10px 22px;margin:0px 0px 6px;border:none;box-shadow:none;text-shadow:none;opacity:0.9;text-transform:uppercase;font-weight:bold;font-size:13px;letter-spacing:0.4px;line-height:1;outline:none;">Post</button>
									</div>						
								  <br>
							</div>
						</form>
					</div>
				</div>				
					<br>
					<?php foreach($posts as $post): ?>
			<?php if(!$post->post_pic == ''): ?>
			<div class="col-md">
            <!-- Box Comment -->
            <div class="card card-widget">
              <div class="card-header">
                <div class="user-block">
                  <img class="img-circle" src="<?php echo base_url();?>profile_upload/<?php echo $post->prof_pic ?>" alt="User Image">
                  <span class="username"><a href="#"><?php echo ucfirst($post->first_name).' '.ucfirst($post->last_name); ?></a></span>
                  <span class="description">Date created - <?php echo $post->date_created ?></span>
                </div>
                <!-- /.user-block -->
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                  </button>
                  <a href="<?php echo base_url();?>user/edit_post/<?php echo $post->post_id; ?>" class="btn btn-tool">Edit Post</i>
                  </a>
                </div>
                <!-- /.card-tools -->
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <img class="img-fluid pad" src="<?php echo base_url(); ?>post_upload/<?php echo $post->post_pic;?>" alt="Photo">

                <p><?php echo $post->content;?></p>
                <button type="button" class="btn btn-default btn-sm"><i class="fas fa-share"></i> Share</button>
                <button type="button" id="<?php echo $post->post_id; ?>" class="likes" class="btn btn-default btn-sm-danger"><i class="far fa-thumbs-up"></i> Like</button>
                <span class="float-right text-muted"><?php //foreach($likes as $like){if($post->post_id == $like->post_id){++$count;}} echo $count;$count =0;  ?> likes - 3 comments</span>
              </div>
              <!-- /.card-body -->
              <div class="card-footer card-comments"> 
				<?php for ($i=0; $i < count($comment) ; $i++):?>
				<?php for ($j=0; $j < count($comment[$i]); $j++):?>
				<?php if($comment[$i][$j]->post_id == $post->post_id): ?>
					<div class="card-comment">
                  	<!-- User image -->
                  		<img class="img-circle img-sm" src="<?php echo base_url(); ?>profile_upload/<?php echo $comment[$i][$j]->user_id->pic_name; ?>" alt="User Image">

                  		<div class="comment-text">
                    		<span class="username">
							<?php echo ucfirst($comment[$i][$j]->user_id->first_name)." ".ucfirst($comment[$i][$j]->user_id->last_name);?>
                    	  	<span class="text-muted float-right"><?php echo $this->custom->get_time($comment[$i][$j]->date_created); ?></span>
                    		</span><!-- /.username -->
                    		<?php echo $comment[$i][$j]->comment ?>
                  		</div>
                  		<!-- /.comment-text -->
                	</div>
                	<!-- /.card-comment -->
				<?php endif;?>
				<?php endfor;?>
				<?php endfor;?>
              </div>
              <!-- /.card-footer -->
              <div class="card-footer">
                <form action="#" method="post">
                  <img class="img-fluid img-circle img-sm" src="<?php echo base_url(); ?>profile_upload/<?php echo $profile_pic->pic_name; ?>" alt="Alt Text">
                  <!-- .img-push is used to add margin to elements next to floating images -->
                  <div class="img-push">
                    <input type="text" name="comment" id="<?php echo $post->post_id; ?>" class="btn btn-outline-light" class="form-control form-control-sm" placeholder="Press enter to post comment">
					<input type="button" class="btn btn-primary comment" value="Comment">
				  </div>
                </form>
              </div>
              <!-- /.card-footer -->
            </div>
            <!-- /.card -->
          </div>


        <?php elseif($post->post_pic==''): ?>
		  <div class="col-md">
            <!-- Box Comment -->
            <div class="card card-widget">
              <div class="card-header">
                <div class="user-block">
                  <img class="img-circle" src="<?php echo base_url();?>profile_upload/<?php echo $post->prof_pic ?>" alt="User Image">
                  <span class="username"><a href="#"><?php echo ucfirst($post->first_name).' '.ucfirst($post->last_name); ?></a></span>
                  <span class="description">Date created - <?php echo $post->date_created ?></span>
                </div>
                <!-- /.user-block -->
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                  </button>
                  <a href="<?php echo base_url();?>user/edit_post/<?php echo $post->post_id; ?>" class="btn btn-tool">Edit Post</i>
                  </a>
                </div>
                <!-- /.card-tools -->
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <!-- post text -->
                <p><?php echo $post->content;?></p>

                <!-- Social sharing buttons -->
                <button type="button" class="btn btn-default btn-sm"><i class="fas fa-share"></i> Share</button>
                <button type="button" id="<?php echo $post->post_id; ?>"  class="likes" class="btn btn-default btn-sm"><i class="far fa-thumbs-up"></i> Like</button>
                <span class="float-right text-muted"><?php //foreach($likes as $like){if($post->post_id == $like->post_id){++$count;}} echo $count;$count =0;  ?> likes - 2 comments</span>
              </div>
              <!-- /.card-body -->
			  <div class="card-footer card-comments">
				<div class="nav"></div>
			  </div>
              <!-- /.card-footer -->
              <div class="card-footer">
                <form action="#" method="post">
                  <img class="img-fluid img-circle img-sm" src="<?php echo base_url(); ?>profile_upload/<?php echo $profile_pic->pic_name; ?>" alt="Alt Text">
                  <!-- .img-push is used to add margin to elements next to floating images -->
                  <div class="img-push">
				  <div class="input-group mb-3">
  				  <input type="text" class="form-control" id="<?php echo $post->post_id; ?>" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="button-addon2">
  					
    				<button class="btn btn-outline-primary comment" type="button" >Comment</button>
  				
				</div>
				  </div>
                </form>

				





              </div>
              <!-- /.card-footer -->
            </div>
            <!-- /.card -->
          </div>
		<?php endif; ?>
		<?php endforeach; ?>
							</div>
							<!-- div post -->

							<div class="col-md-4"><!-- last users-->
								<div class="box box-danger">
									<div class="box-header with-border">
										<h3 class="box-title">Latest Members</h3>

										<div class="box-tools pull-right">
											<span class="label label-danger">8 New Members</span>
							<!-- <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
							</button>
							<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
							</button> -->
						</div>
					</div>
					<!-- /.box-header -->
					<div class="box-body no-padding">
						<ul class="users-list clearfix">
							<li>
								<img src="dist/img/user1-128x128.jpg" alt="User Image">
								<a class="users-list-name" href="#">Alexander Pierce</a>
								<span class="users-list-date">Today</span>
							</li>
							<li>
								<img src="dist/img/user8-128x128.jpg" alt="User Image">
								<a class="users-list-name" href="#">Norman</a>
								<span class="users-list-date">Yesterday</span>
							</li>
							<li>
								<img src="dist/img/user7-128x128.jpg" alt="User Image">
								<a class="users-list-name" href="#">Jane</a>
								<span class="users-list-date">12 Jan</span>
							</li>
							<li>
								<img src="dist/img/user6-128x128.jpg" alt="User Image">
								<a class="users-list-name" href="#">John</a>
								<span class="users-list-date">12 Jan</span>
							</li>
							<li>
								<img src="dist/img/user2-160x160.jpg" alt="User Image">
								<a class="users-list-name" href="#">Alexander</a>
								<span class="users-list-date">13 Jan</span>
							</li>
							<li>
								<img src="dist/img/user5-128x128.jpg" alt="User Image">
								<a class="users-list-name" href="#">Sarah</a>
								<span class="users-list-date">14 Jan</span>
							</li>
							<li>
								<img src="dist/img/user4-128x128.jpg" alt="User Image">
								<a class="users-list-name" href="#">Nora</a>
								<span class="users-list-date">15 Jan</span>
							</li>
							<li>
								<img src="dist/img/user3-128x128.jpg" alt="User Image">
								<a class="users-list-name" href="#">Nadia</a>
								<span class="users-list-date">15 Jan</span>
							</li>
						</ul>
						<!-- /.users-list -->
					</div>
					<!-- /.box-body -->
					<div class="box-footer text-center">
						<a href="javascript:void(0)" class="uppercase">View All Users</a>
					</div>
					<!-- /.box-footer -->
				</div>
				<!--/.box -->
			</div><!-- last users -->

			<br>
			<br>
		</div>
	</div>


	<!--<div class="post">
		<div class="user-block">
			<img class="img-circle img-bordered-sm" src="https://adminlte.io/themes/AdminLTE/dist/img/user7-128x128.jpg" alt="user image">
			<span class="username">
				<a href="#">Jonathan Burke Jr.</a>
			</span>
			<span class="description">Shared publicly - 7:30 PM today</span>
		</div>
							/.user-block
		<p>
		Lorem ipsum represents a long-held tradition for designers,
		typographers and the like. Some people hate it and argue for
		its demise, but others ignore the hate as they create awesome
		tools to help create filler text for everyone from bacon lovers
		to Charlie Sheen fans.
		</p>
		<ul class="list-inline">
			<button class="btn btn-default" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;"> <i class="glyphicon glyphicon-heart" data-aos="flip-right"></i><span> 5 Likes</span></button>
			<button class="btn btn-default comment" type="button" style="color:#eb3b60;background-image:url(&quot;none&quot;);background-color:transparent;">
			<i class="glyphicon glyphicon-flash" style="color:#f9d616;"></i><span style="color:#f9d616;"> 2 Comments</span></button>
			<li><a href="#" class="link-black text-sm"><i class="fa fa-share margin-r-5"></i> Share</a></li>
		</ul>

		<div class="input-group">
			<input type="text" class="form-control" placeholder="Comment">
			<span class="input-group-btn">
				<button type="submit" class="btn btn-danger pull-right btn-block btn-sm" style="background-image:url(&quot;none&quot;);background-color:#da052b;color:#fff;padding:7px">Comment</button>
			</span>
		</div><br>
	</div>-->