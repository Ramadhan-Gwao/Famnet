<?php $this->load->view('layouts/navigation');?>
<?php $this->load->view($main_view);?>