<script>
   $(document).ready(function(){
    $("#send").click(function(){
        $.post("<?php echo base_url(); ?>chats/send_message/<?php echo $conv_id."/".urlencode($user->email); ?>",
        {
          message : $('#message').val(),
        },
          function(data){
              $('.direct-chat-messages').append('<div class="direct-chat-msg right"><div class="direct-chat-text float-right">'+data+'</div></div>')
              $('#message').val('');
          });
    });
  });
</script>