<script>
	$(document).ready(function(){
    	$(".likes").click(function(){
        	$.post("<?php echo base_url(); ?>user/like/"+$(this).attr("id"),
        	function(data,status){
            	alert("Data: " + data + "\nStatus: " + status);
        	});
    	});
      $(".comment").click(function(){
            $.post("<?php echo base_url(); ?>user/comment/"+$(this).siblings().attr('id'),
            {
                comment: $(this).siblings().val()
            },
        	function(data,status){
            var comment = '';
                comment = '<div class=\"card-comment\">';
                comment =+ '<img class=\"img-circle img-sm\" src=\"../dist/img/user3-128x128.jpg\" alt=\"User Image\">';
                comment =+ '<div class=\"comment-text\">';
                comment =+ '<span class=\"username\">';
                comment =+ data;
                comment =+ '<span class="text-muted float-right">8:03 PM Today</span>';
                comment =+ '</span>';
                comment =+ '</div>';
                comment =+ '</div>';
                $(this).parentsUntil('.card-widget').siblings().next().next().append(comment);
                $(this).siblings().val('');
        	});
      
        });
    });
</script>        
