<?php 
    if ($this->session->flashdata('not_loggedin')) {
        $not_loggedin = $this->session->flashdata('not_loggedin');
        $sess_mess = "<div class=\"alert alert-warning alert-dismissible\">
        <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;</button>
        <h5><i class=\"icon fas fa-exclamation-triangle\"></i> Alert!</h5>
        {$not_loggedin}
      </div>";
      echo $sess_mess;
    }
?>
