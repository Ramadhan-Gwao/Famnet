<?php 

    class Project_model extends CI_model{

        public function get_projects(){
            $query = $this->db->get('projects');
            return $query->result();
        }
        public function get_project($id){
            $this->db->where('project_id', $id);
            $query = $this->db->get('projects');
            return $query->row();
        }
        public function get_user_projects_participating(){
            $this->db->where('user_id',$user_id);
            $query = $this->db->get('projects');
            return $query->result();
        }
        public function create_project($data){
            $query = $this->db->insert('projects',$data);
            return $query;
        }
        public function create_budget($data){
            $query = $this->db->insert('Budget',$data);
            return $query;
        }
        public function get_budget($project_id){
            $this->db->where('project_id',$project_id);
            $query = $this->db->get('Budget');
            return $query->row();
        }
        public function edit_project($project_id,$data){
            $this->db->where('project_id',$project_id);
            $query = $this->db->update('projects',$data);
            return $query;
        }
        public function edit_budget($project_id,$data){
            $this->db->where('budget_id',$project_id);
            $query = $this->db->update('Budget',$data);
            return $query;
        }
        public function get_last_project_id(){
            $query = $this->db->get('projects');
            return $query->last_row()->project_id;
        }
        public function delete_project($project_id){
            $this->db->where('project_id',$project_id);
            $query = $this->db->delete('projects');
            return $query;
        }
        public function delete_budget($project_id){
            $this->db->where('project_id',$project_id);
            $query = $this->db->delete('Budget');
            return $query;
        }
        public function get_all_user_projects($user_id){
            $this->db->where('project_user_id',$user_id);
            $query = $this->db->get('projects');
            return $query->result();
        }
        public function get_project_name($project_id){
            $this->db->where('project_id',$project_id);
            $query = $this->db->get('projects');
            return $query->row()->project_name;
        }
        public function add_project_participants($data){
            $query = $this->db->insert('project_participants',$data);
            return $query;
        }
        public function remove_project_participant($user_id,$project_id){
            $this->db->where('project_id',$project_id);
            $this->db->where('participant_id',$user_id);
            $query = $this->db->delete('project_participants');
            return $query;
        }
        public function get_all_project_participants($project_id){
            $this->db->where('project_id',$project_id);
            $query = $this->db->get('project_participants');
            return $query->result();
        }
        public function add_project_status($data){
            $query = $this->db->insert('project_status',$data);
            return $query;
        }
        public function delete_project_status($id){
            $this->db->where('project_status_id',$id);
            $query = $this->db->delete('project_status');
            return $query;
        }
    }
?>