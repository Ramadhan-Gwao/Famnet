<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {
    public function register_new_user($data){
        $query = $this->db->insert('user',$data);
        return $query;
    }
    public function user_login($email,$password){
        $this->db->where('email',$email);
        $query = $this->db->get('user');
        if(password_verify($password,$query->row(0)->password)){
            return $query->row(0)->id;
        }else {
            return false;
        }
    }
    public function get_user_names($user_id){
        $this->db->select('user.first_name,user.last_name,profile_pictures.pic_name,user.email');
        $this->db->select('user');
        $this->db->join('profile_pictures', 'user.id = profile_pictures.user_id');
        
        $this->db->where('id', $user_id);
        $query = $this->db->get('user');
        return array ('first_name'=> $query->row(0)->first_name,'last_name'=>$query->row(0)->last_name);
    }
    public function get_users_credentials(){
        $this->db->select('user.first_name , user.last_name , user.is_active , user.email , user.updated_at , profile_pictures.pic_name ');
        $this->db->from('user');
        $this->db->join('profile_pictures','profile_pictures.user_id=user.id');
        $query = $this->db->get();
        return $query->result();
    }
    public function get_user_credentials($user_id){
        $this->db->select('user.first_name , user.last_name , user.is_active , user.email , user.updated_at , profile_pictures.pic_name ');
        $this->db->from('user');
        $this->db->join('profile_pictures','user.id = profile_pictures.user_id');
        $this->db->where('user.id',$user_id);
        $this->db->where('profile_pictures.active', 1);
        $query = $this->db->get();
        return $query->row();
    }
    public function user_data_update($id,$data){
        $this->db->where('id',$id);
        $query = $this->db->update('user',$data);
        return $query;
    }
    public function get_users(){
        $query = $this->db->get('user');
        return $query->result();
    }
    public function get_user_data($user_id){
        $this->db->where('id',$user_id);
        $query = $this->db->get('user');
        return $query->row();
    }
    public function get_user_by_email($email){
        $this->db->where('email',$email);
        $query = $this->db->get('user');
        if ($query->num_rows()==1) {
            return $query->row(0)->id;
        }else{
            return false;
        }
    }

    public function activate_user($user_id){
        $this->db->set('is_active',1);
        $this->db->where('id',$user_id);
        $query = $this->db->update('user');
        return $query;
    }
    public function deactivate_user($user_id){
        $this->db->set('is_active',0);
        $this->db->where('id',$user_id);
        $query = $this->db->update('user');
        return $query;
    }
    public function report_user($user_id){
        $this->db->set('is_reported',1);
        $this->db->where('id',$user_id);
        $query = $this->db->update('user');
        return $query;
    }
    public function de_report_user($user_id){
        $this->db->set('is_reported',0);
        $this->db->where('id',$user_id);
        $query = $this->db->update('user');
        return $query;
    }
    public function block_user($user_id){
        $this->db->set('is_blocked',1);
        $this->db->where('id',$user_id);
        $query = $this->db->update('user');
        return $query;
    }
    public function unblock_user($user_id){
        $this->db->set('is_blocked',0);
        $this->db->where('id',$user_id);
        $query = $this->db->update('user');
        return $query;
    }
    public function user_available($user_id){
        $this->db->where('id',$user_id);
        $query = $this->db->get('user');
        return $query->row(0)->is_active;
    }
    public function user_blocked($user_id){
        $this->db->where('id',$user_id);
        $query = $this->db->get('user');
        return $query->row(0)->is_blocked;
    }
    public function user_reported($user_id){
        $this->db->where('id',$user_id);
        $query = $this->db->get('user');
        return $query->row(0)->is_reported;
    }
    public function user_first_name($user_id){
        $this->db->where('id',$user_id);
        $query = $this->db->get('user');
        return $query->row(0)->first_name;
    }
    public function user_last_name($user_id){
        $this->db->where('id',$user_id);
        $query = $this->db->get('user');
        return $query->row(0)->last_name;
    }
    public function delete_user_account($user_id){
        $this->db->where('id',$user_id);
        $query = $this->db->delete('user');
        return $query;
    }
    public function insert_contacts($data){
        $query =$this->db->insert('contacts',$data);
        return $query;
    }
    public function get_user_contacts($user_id){
        $this->db->where('user_id',$user_id);
        $query = $this->db->get('contacts');
        return $query->row(0);
    }
    public function delete_user_contacts($user_id){
        $this->db->where('user_id',$user_id);
        $query = $this->db->delete('contacts');
        return $query;
    }
    public function update_user_contacts($user_id,$data){
        $this->db->where('user_id',$user_id);
        $query = $this->db->update('contacs',$data);
        return $query;
    }
    public function insert_user_about($data){
        $query =$this->db->insert('user_about',$data);
        return $query;
    }
    public function update_user_about($user_id,$data){
        $this->db->where('user_id',$user_id);
        $query = $this->db->update('contacs',$data);
        return $query;
    }
    public function check_user_about($user_id){
        $this->db->where('user_id',$user_id);
        $query = $this->db->get('user_about');
        if ($query->count_all_result()<1) {
            return false;
        }
        else {
            return true;
        }
    }
    public function check_user_contacts($user_id){
        $this->db->where('user_id',$user_id);
        $query = $this->db->get('contacts');
        if ($query->result()<1) {
            return false;
        }
        else {
            return true;
        }
    }
    public function create_user_notifications($data){
        $this->db->insert('notifications',$data);
        return $query;
    }
    public function get_user_notifications($user_id){
        $this->db->where('user_id',$user_id);
        $query = $this->db->get('notifications');
        return $query;
    }
    public function update_user_message($user_id,$data){
        $this->db->where('user_id',$user_id);
        $query = $this->db->update('notifications',$data);
        return $query;
    }
    public function update_user_comment($user_id,$data){
        $this->db->where('user_id',$user_id);
        $query = $this->db->update('notifications',$data);
        return $query;
    }
    public function update_user_news($user_id,$data){
        $this->db->where('user_id',$user_id);
        $query = $this->db->update('notifications',$data);
        return $query;
    }

}