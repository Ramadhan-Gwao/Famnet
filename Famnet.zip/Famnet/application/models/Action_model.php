<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Action_model extends CI_Model {
    public function create_post($data){
        $query = $this->db->insert('posts',$data);
        return $query;
    }
    public function update_post($post_id,$data){
        $this->db->where('post_id',$post_id);
        $query = $this->db->update('posts',$data);
        return $query;
    }
    public function get_user_post($post_id){
        $this->db->where('post_id',$post_id);
        $query = $this->db->get('posts');
        return $query->row();
    }
    public function get_user_posts($user_id){
        $this->db->select('user.first_name,user.last_name, profile_pictures.pic_name as prof_pic,posts.content,posts.date_created,posts.pic_name as post_pic,posts.post_id');
        $this->db->from('posts');
        $this->db->join('user','user.id = posts.user_id');
        $this->db->join('profile_pictures','profile_pictures.user_id=user.id');
        $this->db->where('profile_pictures.active',1);
        $this->db->where('posts.user_id',$user_id);
        $this->db->limit(10);
        $this->db->order_by('date_created');
        $query = $this->db->get();
        return $query->result();
    }
    public function get_post($post_id){
        $this->db->select('user.first_name,user.last_name,profile_pictures.pic_name as prof_pic,posts.content,posts.date_created,posts.pic_name as post_pic,posts.post_id');
        $this->db->from('posts');
        $this->db->join('user','user.id = posts.user_id');
        $this->db->join('profile_pictures','profile_pictures.user_id=user.id');
        $this->db->where('profile_pictures.active',1);
        $this->db->where('posts.post_id', $post_id);
        $query = $this->db->get();
        return $query->row();
    }
    public function get_last_user_post($user_id){
        $this->db->where('user_id',$user_id);
        $query = $this->db->get('posts');
        return $query->last_row();
    }
    public function delete_post($post_id){
        $this->db->where('post_id',$post_id);
        $query = $this->db->delete('posts');
        return $query;
    }
    public function get_posts(){
        $this->db->select('user.first_name,user.last_name, profile_pictures.pic_name as prof_pic,posts.content,posts.date_created,posts.pic_name as post_pic,posts.post_id');
        $this->db->from('posts');
        $this->db->join('user','user.id = posts.user_id');
        $this->db->join('profile_pictures','profile_pictures.user_id=user.id');
        $this->db->where('profile_pictures.active',1);
        $this->db->limit(10);
        $this->db->order_by('date_created','RANDOM');
        $query = $this->db->get();
        return $query->result();
    }
    public function check_like($post_id,$user_id){
        $this->db->where('post_id',$post_id);
        $this->db->where('user_id',$user_id);
        $query = $this->db->get('likes');
        if($query->num_rows()==1){
            return true;
        }else {
            return false;
        }
    }
    public function like_post($post_id,$user_id){
        $data = array('post_id' => $post_id,'user_id'=>$user_id,'active'=>1);
        $query = $this->db->insert('likes',$data);
        return $query;
    }
    public function re_like_post($post_id,$user_id){
        $this->db->set('active',1);
        $this->db->where('post_id', $post_id);
        $this->db->where('user_id', $user_id);
        $query = $this->db->update('likes');
        return $query;
    }
    public function unlike_post($post_id,$user_id){
        $this->db->set('active',0);
        $this->db->where('post_id',$post_id);
        $this->db->where('user_id',$user_id);
        $query = $this->db->update('likes');
        return $query;
    }
    public function check_active_like($post_id,$user_id){
        $this->db->where('post_id',$post_id);
        $this->db->where('user_id',$user_id);
        $this->db->where('active', 1);
        $query = $this->db->get('likes');
        if ($query->num_rows()<1) {
            return true;
        }else{
            return false;
        }
    }
    public function get_post_likes($post_id){
        $this->db->where('post_id',$post_id);
        $this->db->where('active',1);
        $query = $this->db->get('likes');
        return $query->result();
    }
    public function get_user_likes($user_id){
        $this->db->where('user_id',$user_id);
        $query = $this->db->get('likes');
        return $query->result();
    }
    public function create_report($data){
        $query = $this->db->insert('reports',$data);
        return $query;
    }
    public function mark_user_reported($user_id){
        $this->db->set('is_reported',1);
        $this->db->where('id',$user_id);
        $query = $this->db->update('user');
        return $query;
    }
    public function unmark_user_reported($user_id){
        $this->db->set('is_reported',0);
        $this->db->where('id',$user_id);
        $query = $this->db->update('user');
        return $query;
    }   
    public function upload_post_picture($data){
        $query = $this->db->insert('post_pictures',$data);
        return $query;
    }
    public function delete_post_picture($picture_id){
        $this->db->where('post_pic_id',$picture_id);
        $query = $this->db->delete('post_pictures');
        return $query;
    }
    public function get_post_picture($post_id){
        $this->db->where('post_id',$post_id);
        $query = $this->db->get('post_pictures');
        return $query->result();
    }
    public function get_user_post_pictures($user_id){
        $this->db->where('user_id',$user_id);
        $query = $this->db->get('post_pictures');
        return $query->result();
    }
    public function delete_post_pictures($post_id){
        $this->db->where('post_id',$post_id);
        $query = $this->db->delete('post_pictures');
        return $query;
    }
    public function comment($data){
        $query = $this->db->insert('post_comments',$data);
        return $query;
    }
    public function get_post_comments($post_id){
        $this->db->where('post_id',$post_id);
        $query = $this->db->get('post_comments');
        return $query->result();
    }
    public function delete_comment(){
        $this->db->where('post_comment_id',$post_id);
        $query = $this->db->delete('post_comments');
        return $query;
    }
    public function get_user_comments(){
        $this->db->where('user_id',$user_id);
        $query = $this->db->get('post_comments');
        return $query->result();
    }
    public function get_inputs($post_id,$user_id){
        $this->db->where('post_id',$post_id);
        $this->db->where('user_id',$user_id);
        $query = $this->db->get('post_comments');
        return $query->result();
    }
}
/*$phpdate = strtotime( $mysqldate );
$mysqldate = date( 'Y-m-d H:i:s', $phpdate );*/