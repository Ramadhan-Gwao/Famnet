<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chat_model extends CI_Model {
    public function create_chat($data){
        $query = $this->db->insert('conversations',$data);
        return $query;
    }
    public function delete_chat($chat_id){
        $this->db->where('conversation_id',$chat_id);
        $query = $this->db->delete('conversations');
        return $query;
    }
    public function compose_message($data){
        $query = $this->db->insert('message',$data);
        return $query;
    }
    public function delete_message($message_id){
        $this->db->where('message_id',$message_id);
        $query = $this->db->delete('message');
        return $query;
    }
    public function view_messages($message_id){
        $this->db->set('viewed',1);
        $this->db->where('conv_id',$conv_id);
        $query = $this->db->update('message');
    }
    public function user_unread_messages($user_id){
        $this->db->where('user_id',$user_id);
        $this->db->where('viewed',0);
        $query = $this->db->get('message');
        return $query->result();
    }
    public function get_chat_messages($conv_id){
        $this->db->where('conv_id',$conv_id);
        $query = $this->db->get('message');
        return $query->result();
    }
    public function get_sender_chat_message($user_id,$conv_id){
        $this->db->where('sender_id',$user_id);
        $this->db->where('conv_id',$conv_id);
        $this->db->order_by('date_created');
        $query = $this->db->get('message');
        return $query->result();
    }
    public function get_all_users_chat_messages($user_id,$participant_id,$conv_id){
        $this->db->where('conv_id',$conv_id);
        $this->db->or_where('participant_id',$participant_id);
        $this->db->group_by('date_created');
        $query = $this->db->get('message');
        return $query->result();
    }
    public function get_all_user_chat($user_id){
        $this->db->where('user_id',$user_id);
        $this->db->group_by('updated_at');
        $query = $this->db->get('conversations');
        return $query->result();
    }
    public function get_all_user_chats($user_id){
        $this->db->where('creator_id',$user_id);
        $this->db->or_where('participant_id',$user_id);
        $query = $this->db->get('conversations');
        if($query->num_rows()<1){
            return FALSE;
        }
        return $query->result();
    }
    public function get_user_unviewed_messages($conv_id){
        $this->db->where('viewed', 0);
        $this->db->where('conv_id',$conv_id);
        $this->db->get('message');
    }
    
    
}
?>