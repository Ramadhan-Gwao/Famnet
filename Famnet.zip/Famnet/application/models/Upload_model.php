<?php  
class Upload_model extends CI_Model{
    public function upload_profile_picture($data){
        $query = $this->db->insert('profile_pictures',$data);
        return $query;
    }
    public function get_user_profile_pictures($user_id){
        $this->db->where('user_id',$user_id);
        $result = $this->db->get('profile_pictures');
        return $result->result();
    }
    public function get_user_active_profile_picture($user_id){
        $this->db->where('user_id',$user_id);
        $this->db->where('active',1);
        $result = $this->db->get('profile_pictures');
        return $result->row();
    }
    public function unmark_profile_pictures($user_id){
        $this->db->set('active',0);
        $this->db->where('user_id',$user_id);
        $result = $this->db->update('profile_pictures');
        return $result;
    }
    public function mark_profile_picture($user_id){
        $this->db->set('active',1);
        $this->db->where('prof_pic_id',$pic_id);
        $result = $this->db->update('profile_pictures');
        return $result;
    }
    public function delete_profile_pic($pic_id){
        $this->db->where('prof_pic_id',$pic_id);
        $result = $this->db->delete('profile_pictures');
        return $result;
    }
    public function upload_post_picture($data){
        $query = $this->db->insert('post_pictures',$data);
        return $query;
    }
    public function get_user_post_pictures($user_id){
        $this->db->where('user_id',$user_id);
        $result = $this->db->get('post_pictures');
        return $result->result();
    }
    public function get_post_picture(){
        $this->db->where('post_id',$post_id);
        $query = $this->db->get('post_pictures');
        return $query->result();
    }
    public function delete_post_pic($pic_id){
        $this->db->where('post_pic_id',$pic_id);
        $result = $this->db->delete('profile_pictures');
        return $result;
    }

    public function upload_project_picture($data){
        $query = $this->db->insert('project_pictures',$data);
        return $query;
    }
    public function get_project_pictures($project_id){
        $this->db->where('project_id',$project_id);
        $result = $this->db->get('project_pictures');
        return $result->result();
    }
    public function delete_project_pic($pic_id){
        $this->db->where('project_pic_id',$pic_id);
        $result = $this->db->delete('project_pictures');
        return $result;
    }
    public function get_last_project_picture(){
        $result = $this->db->get('project_pictures');
        return $result->last_row()->project_pic_id;
    }
    public function check(){
        $query = $this->db->get('profile_pictures');
        return $query->result();
    }
    public function check_post_picture(){
        $query = $this->db->get('post_pictures');
        return $query->last_row();
    }
}
?>